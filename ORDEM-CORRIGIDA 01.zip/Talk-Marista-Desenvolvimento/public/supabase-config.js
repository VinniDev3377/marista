/*
 * Configuração pública do Supabase.
 * Preencha somente com a URL do projeto e a chave publishable/anon.
 * Nunca coloque service_role, senha ou PIN neste arquivo.
 */
window.TALK_MARISTA_SUPABASE_CONFIG = Object.freeze({
  url: "https://zzwtmbhguccwhkcuxoyk.supabase.co",
  publishableKey: "COLE_AQUI_SUA_CHAVE_SB_PUBLISHABLE"
});
