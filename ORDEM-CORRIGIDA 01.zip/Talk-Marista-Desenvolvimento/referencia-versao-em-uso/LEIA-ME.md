# Referência do aplicativo atualmente em uso

Esta pasta guarda uma cópia sem alterações do pacote `Talk-Marista-Login-Morador-Portaria.zip` recuperado do histórico, para consulta e comparação durante a evolução do código editável.

**Não publique esta pasta como versão nova.** O arquivo `app.js` é compilado/minificado e não substitui os fontes em `src/`. O `supabase-config.js` preservado nesta referência contém apenas o marcador da chave pública, não a chave inserida localmente no computador.
