# Talk Marista — integração Supabase (etapa 1)

## O que foi conectado
- SDK oficial `@supabase/supabase-js` v2 carregado antes do aplicativo.
- Cliente Supabase criado a partir de `supabase-config.js`.
- Persistência de sessão, renovação automática do token e detecção de retorno de autenticação ativadas.
- Consulta do perfil autenticado em `public.profiles` mantida no fluxo existente.

## Configuração
O arquivo `supabase-config.js` contém a URL e a chave pública publishable do projeto. Essa chave é destinada ao navegador. Não substitua por `service_role`.

## Limite desta etapa
Esta etapa conecta o cliente e habilita o caminho de login por e-mail e senha já previsto no aplicativo. Ainda não implementa o cadastro de novos moradores, o login por nome + apartamento, a sincronização dos módulos nem a tela de aprovação/rejeição. Esses pontos dependem da implementação segura do backend/Edge Function e do mapeamento das tabelas.

## Testes necessários
1. Hospedar em ambiente HTTPS de teste ou servir localmente.
2. Entrar com uma conta Auth existente e sua senha.
3. Confirmar que o perfil correspondente é carregado de `public.profiles`.
4. Testar saída e reentrada.

Não inserir `service_role` no navegador e não usar contas de demonstração para dados reais.
