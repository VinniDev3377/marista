/*
 * Configuração pública do Supabase para o Talk Marista.
 * A chave publishable/anon pode ser usada no navegador porque a segurança
 * dos dados deve ser garantida pelas políticas RLS do banco.
 * NUNCA coloque a chave service_role neste arquivo.
 */
window.TALK_MARISTA_SUPABASE_CONFIG = Object.freeze({
  url: "https://zzwtmbhguccwhkcuxoyk.supabase.co",
  publishableKey: "COLE_AQUI_SUA_CHAVE_SB_PUBLISHABLE"
});
