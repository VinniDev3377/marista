# Talk Marista — antes de instalar o banco

Este arquivo acompanha `SUPABASE-INSTALACAO-INICIAL.sql`.

1. O script cria a estrutura inicial dos módulos presentes no aplicativo atual: apartamentos, perfis, convites, moradores, visitantes, familiares, prestadores, encomendas e histórico, acessos, reservas, mudanças e solicitações.
2. Ele cria os 88 apartamentos do intervalo 301–2404 (quatro unidades por andar).
3. Ele ativa RLS e aplica políticas para separar dados por apartamento e permitir operação da Portaria.
4. Novas contas Auth recebem perfil `morador`. A função de convite associa o usuário a um apartamento sem permitir escolher livremente o apartamento no cadastro.
5. O perfil da Portaria não é criado por cadastro público. Deve ser atribuído manualmente a uma conta confiável após sua criação no Supabase Auth.
6. **Não execute ainda**: este SQL prepara o banco, mas o aplicativo ainda precisa da implementação de autenticação e sincronização Supabase. A integração do frontend deve ser concluída e testada antes de usar dados reais.
7. Não coloque `service_role` no frontend. A chave publishable/anon pode ficar na configuração pública do app, com RLS corretamente habilitado.

O script é uma base inicial, não uma confirmação de que a aplicação já está conectada.
