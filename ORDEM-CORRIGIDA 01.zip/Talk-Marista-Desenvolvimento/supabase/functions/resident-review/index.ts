// Aprova ou recusa cadastro; exige sessão autenticada com perfil Portaria.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);
  try {
    const token = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
    if (!token) return json({ error: "Sessão necessária." }, 401);
    const url = Deno.env.get("SUPABASE_URL")!;
    const anon = Deno.env.get("SUPABASE_ANON_KEY")!;
    const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const caller = createClient(url, anon, { global: { headers: { Authorization: `Bearer ${token}` } } });
    const { data: authData, error: authError } = await caller.auth.getUser(token);
    if (authError || !authData.user) return json({ error: "Sessão inválida." }, 401);
    const admin = createClient(url, service, { auth: { persistSession: false } });
    const { data: staff } = await admin.from("profiles").select("role").eq("id", authData.user.id).maybeSingle();
    if (staff?.role !== "portaria") return json({ error: "Somente a Portaria pode revisar cadastros." }, 403);

    const { requestId, decision, reason } = await req.json();
    if (typeof requestId !== "string" || !["approve", "reject"].includes(decision)) return json({ error: "Solicitação inválida." }, 400);
    const { data: request, error: readError } = await admin.from("resident_registration_requests").select("*").eq("id", requestId).eq("status", "pending").single();
    if (readError || !request) return json({ error: "Cadastro não encontrado ou já analisado." }, 404);

    if (decision === "approve") {
      const { error: profileError } = await admin.from("profiles").insert({ id: request.auth_user_id, full_name: request.full_name, apartment: request.apartment, role: "morador" });
      if (profileError) return json({ error: profileError.message }, 400);
    }
    // Conta recusada permanece sem perfil ativo; assim preservamos o registro de auditoria.
    const { error: updateError } = await admin.from("resident_registration_requests").update({ status: decision === "approve" ? "approved" : "rejected", reviewed_at: new Date().toISOString(), reviewed_by: authData.user.id, rejection_reason: decision === "reject" ? String(reason ?? "") : null }).eq("id", requestId).eq("status", "pending");
    if (updateError) return json({ error: updateError.message }, 500);
    if (decision === "reject") {
      // Exclui a credencial recusada, mantendo o pedido de auditoria (FK ON DELETE SET NULL).
      const { error: deleteError } = await admin.auth.admin.deleteUser(request.auth_user_id);
      if (deleteError) return json({ error: "Pedido recusado, mas não foi possível invalidar a credencial. Contate o suporte." }, 500);
    }
    return json({ message: decision === "approve" ? "Morador aprovado." : "Cadastro recusado." });
  } catch (_error) { return json({ error: "Não foi possível revisar o cadastro." }, 500); }
});
