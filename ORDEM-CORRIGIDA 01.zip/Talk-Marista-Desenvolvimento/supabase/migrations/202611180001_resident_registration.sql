-- Cadastro de moradores com aprovação obrigatória da Portaria.
create table if not exists public.resident_registration_requests (
  id uuid primary key default gen_random_uuid(),
  auth_user_id uuid unique references auth.users(id) on delete set null,
  full_name text not null,
  apartment text not null references public.apartments(number),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(), reviewed_at timestamptz,
  reviewed_by uuid references auth.users(id), rejection_reason text
);
create unique index if not exists resident_registration_one_pending_identity
on public.resident_registration_requests (lower(regexp_replace(full_name, '\s+', ' ', 'g')), apartment)
where status = 'pending';
alter table public.resident_registration_requests enable row level security;
revoke all on public.resident_registration_requests from anon, authenticated;
grant select on public.resident_registration_requests to authenticated;
drop policy if exists resident_requests_portaria_read on public.resident_registration_requests;
create policy resident_requests_portaria_read on public.resident_registration_requests
for select to authenticated using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'portaria'));
comment on table public.resident_registration_requests is 'Fila privada. Criação e revisão somente pelas Edge Functions resident-register e resident-review.';


-- Impede que o trigger legado crie automaticamente um perfil ativo para uma
-- conta recém-criada com registration_pending=true. Mantém a conta de Portaria
-- existente intacta; perfis de novos usuários passam a ser criados após aprovação.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if coalesce(new.raw_user_meta_data ->> 'registration_pending', 'false') = 'true' then
    return new;
  end if;
  -- Nenhum perfil privilegiado é criado automaticamente por metadados do cliente.
  return new;
end;
$$;
revoke all on function public.handle_new_user() from public, anon, authenticated;
