-- TALK MARISTA | Notificações individuais por apartamento
-- Migração incremental: não apaga nem modifica registros existentes.
-- Pré-requisitos: public.profiles e public.apartments já existentes.

begin;

create table if not exists public.apartment_notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  apartment text not null references public.apartments(number) on delete cascade,
  title text not null,
  body text not null,
  event_type text not null,
  source_table text,
  source_id text,
  created_at timestamptz not null default now(),
  read_at timestamptz
);

create index if not exists apartment_notifications_user_created_idx
  on public.apartment_notifications (user_id, created_at desc);

alter table public.apartment_notifications enable row level security;
revoke all on public.apartment_notifications from anon, authenticated;
grant select on public.apartment_notifications to authenticated;
grant update (read_at) on public.apartment_notifications to authenticated;

drop policy if exists apartment_notifications_read_own on public.apartment_notifications;
create policy apartment_notifications_read_own
  on public.apartment_notifications for select to authenticated
  using (user_id = auth.uid());

drop policy if exists apartment_notifications_mark_own_read on public.apartment_notifications;
create policy apartment_notifications_mark_own_read
  on public.apartment_notifications for update to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- Função genérica: gera uma notificação separada para cada morador do apartamento.
create or replace function public.talk_marista_notify_apartment_event()
returns trigger
language plpgsql
security definer
set search_path = pg_catalog, public
as $function$
declare
  v_new jsonb := to_jsonb(new);
  v_old jsonb;
  v_apartment text;
  v_person text;
  v_title text;
  v_body text;
  v_event text;
  v_source_id text;
begin
  if tg_op = 'UPDATE' then v_old := to_jsonb(old); end if;
  v_apartment := nullif(v_new ->> 'apartment', '');
  if v_apartment is null then return new; end if;

  v_person := coalesce(nullif(v_new ->> 'name', ''), nullif(v_new ->> 'full_name', ''), nullif(v_new ->> 'recipient', ''), nullif(v_new ->> 'person', ''), 'Registro atualizado');
  v_source_id := coalesce(v_new ->> 'id', '');

  if tg_table_name = 'packages' then
    if tg_op = 'INSERT' then
      v_title := 'Encomenda recebida';
      v_body := 'Uma encomenda para ' || v_person || ' foi cadastrada na portaria.';
      v_event := 'package_received';
    elsif v_new ->> 'status' is distinct from v_old ->> 'status' then
      v_title := 'Atualização de encomenda';
      v_body := 'A encomenda de ' || v_person || ' foi atualizada: ' || coalesce(v_new ->> 'status', 'status alterado') || '.';
      v_event := 'package_status';
    else return new;
    end if;
  elsif tg_table_name = 'visitors' then
    v_title := case when tg_op = 'INSERT' then 'Visitante cadastrado' else 'Atualização de visitante' end;
    v_body := v_person || ' · ' || coalesce(v_new ->> 'status', 'autorização registrada') || '.';
    v_event := 'visitor_' || lower(tg_op);
  elsif tg_table_name = 'workers' then
    v_title := case when tg_op = 'INSERT' then 'Prestador ou funcionário cadastrado' else 'Cadastro de prestador atualizado' end;
    v_body := v_person || ' · ' || coalesce(v_new ->> 'worker_type', 'pessoa autorizada') || '.';
    v_event := 'worker_' || lower(tg_op);
  elsif tg_table_name = 'family_members' then
    if tg_op <> 'INSERT' then return new; end if;
    v_title := 'Familiar cadastrado';
    v_body := v_person || ' foi adicionado à lista de familiares.';
    v_event := 'family_created';
  elsif tg_table_name = 'accesses' then
    v_title := 'Movimentação de acesso';
    v_body := v_person || ' · ' || coalesce(v_new ->> 'status', 'movimentação registrada') || '.';
    v_event := 'access_' || lower(tg_op);
  else
    return new;
  end if;

  insert into public.apartment_notifications
    (user_id, apartment, title, body, event_type, source_table, source_id)
  select p.id, v_apartment, v_title, v_body, v_event, tg_table_name, v_source_id
    from public.profiles p
   where p.apartment = v_apartment
     and p.role = 'morador';

  return new;
end;
$function$;

revoke all on function public.talk_marista_notify_apartment_event() from public, anon, authenticated;

-- Instala somente triggers em tabelas que já existem no banco do condomínio.
do $install$
declare
  v_table text;
begin
  foreach v_table in array array['packages','visitors','workers','family_members','accesses'] loop
    if to_regclass('public.' || v_table) is not null then
      execute format('drop trigger if exists talk_marista_notify_event on public.%I', v_table);
      execute format('create trigger talk_marista_notify_event after insert or update on public.%I for each row execute function public.talk_marista_notify_apartment_event()', v_table);
    end if;
  end loop;
end;
$install$;

-- Ativa entrega em tempo real, caso a publicação padrão do Supabase esteja presente.
do $realtime$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (
       select 1 from pg_publication_tables
        where pubname = 'supabase_realtime'
          and schemaname = 'public'
          and tablename = 'apartment_notifications'
     ) then
    alter publication supabase_realtime add table public.apartment_notifications;
  end if;
end;
$realtime$;

commit;
