-- Reaplica políticas de segurança conhecidas do Talk Marista sem desativar RLS.
-- Políticas com estes nomes são substituídas; outras políticas não são removidas.
begin;

create or replace function public.current_user_role()
returns text language sql stable security definer set search_path = public
as $$ select role from public.profiles where id = auth.uid() $$;

create or replace function public.current_user_apartment()
returns text language sql stable security definer set search_path = public
as $$ select apartment from public.profiles where id = auth.uid() $$;

create or replace function public.is_portaria()
returns boolean language sql stable security definer set search_path = public
as $$ select coalesce(public.current_user_role() = 'portaria', false) $$;

alter table public.apartments enable row level security;
alter table public.profiles enable row level security;
alter table public.apartment_invites enable row level security;
alter table public.residents enable row level security;
alter table public.visitors enable row level security;
alter table public.family_members enable row level security;
alter table public.workers enable row level security;
alter table public.packages enable row level security;
alter table public.package_events enable row level security;
alter table public.accesses enable row level security;
alter table public.reservations enable row level security;
alter table public.moves enable row level security;
alter table public.service_requests enable row level security;

-- Remove apenas os nomes de policies que esta migração administra.
do $$ declare item record; begin
  for item in select * from (values
    ('apartments','tm_apartments_read'),('profiles','tm_profiles_read'),('profiles','tm_profiles_update'),
    ('apartment_invites','tm_invites_portaria'),('residents','tm_residents_read'),('residents','tm_residents_write'),
    ('visitors','tm_visitors_read'),('visitors','tm_visitors_insert'),('visitors','tm_visitors_update'),('visitors','tm_visitors_delete'),
    ('family_members','tm_family_read'),('family_members','tm_family_write'),('workers','tm_workers_read'),('workers','tm_workers_write'),
    ('packages','tm_packages_read'),('packages','tm_packages_insert'),('packages','tm_packages_update'),
    ('package_events','tm_package_events_read'),('package_events','tm_package_events_insert'),
    ('accesses','tm_accesses_read'),('accesses','tm_accesses_write'),
    ('reservations','tm_reservations_read'),('reservations','tm_reservations_insert'),('reservations','tm_reservations_update'),('reservations','tm_reservations_delete'),
    ('moves','tm_moves_read'),('moves','tm_moves_insert'),('moves','tm_moves_update'),('moves','tm_moves_delete'),
    ('service_requests','tm_service_requests_read'),('service_requests','tm_service_requests_insert'),('service_requests','tm_service_requests_update')
  ) as v(tablename, policyname)
  loop execute format('drop policy if exists %I on public.%I', item.policyname, item.tablename); end loop;
end $$;

create policy tm_apartments_read on public.apartments for select to authenticated using (true);
create policy tm_profiles_read on public.profiles for select to authenticated using (id = auth.uid() or public.is_portaria());
create policy tm_profiles_update on public.profiles for update to authenticated using (id = auth.uid() or public.is_portaria()) with check (id = auth.uid() or public.is_portaria());
create policy tm_invites_portaria on public.apartment_invites for all to authenticated using (public.is_portaria()) with check (public.is_portaria());

create policy tm_residents_read on public.residents for select to authenticated using (public.is_portaria() or apartment = public.current_user_apartment());
create policy tm_residents_write on public.residents for all to authenticated using (public.is_portaria()) with check (public.is_portaria());

create policy tm_visitors_read on public.visitors for select to authenticated using (public.is_portaria() or apartment = public.current_user_apartment());
create policy tm_visitors_insert on public.visitors for insert to authenticated with check (public.is_portaria() or (apartment = public.current_user_apartment() and created_by = auth.uid()));
create policy tm_visitors_update on public.visitors for update to authenticated using (public.is_portaria()) with check (public.is_portaria());
create policy tm_visitors_delete on public.visitors for delete to authenticated using (public.is_portaria());

create policy tm_family_read on public.family_members for select to authenticated using (public.is_portaria() or apartment = public.current_user_apartment());
create policy tm_family_write on public.family_members for all to authenticated using (public.is_portaria() or (apartment = public.current_user_apartment() and created_by = auth.uid())) with check (public.is_portaria() or (apartment = public.current_user_apartment() and created_by = auth.uid()));
create policy tm_workers_read on public.workers for select to authenticated using (public.is_portaria() or apartment = public.current_user_apartment());
create policy tm_workers_write on public.workers for all to authenticated using (public.is_portaria() or (apartment = public.current_user_apartment() and created_by = auth.uid())) with check (public.is_portaria() or (apartment = public.current_user_apartment() and created_by = auth.uid()));

create policy tm_packages_read on public.packages for select to authenticated using (public.is_portaria() or apartment = public.current_user_apartment());
create policy tm_packages_insert on public.packages for insert to authenticated with check (public.is_portaria());
create policy tm_packages_update on public.packages for update to authenticated using (public.is_portaria()) with check (public.is_portaria());
create policy tm_package_events_read on public.package_events for select to authenticated using (public.is_portaria() or apartment = public.current_user_apartment());
create policy tm_package_events_insert on public.package_events for insert to authenticated with check (public.is_portaria());

create policy tm_accesses_read on public.accesses for select to authenticated using (public.is_portaria() or apartment = public.current_user_apartment());
create policy tm_accesses_write on public.accesses for all to authenticated using (public.is_portaria()) with check (public.is_portaria());

create policy tm_reservations_read on public.reservations for select to authenticated using (public.is_portaria() or apartment = public.current_user_apartment());
create policy tm_reservations_insert on public.reservations for insert to authenticated with check (apartment = public.current_user_apartment() and created_by = auth.uid());
create policy tm_reservations_update on public.reservations for update to authenticated using (public.is_portaria()) with check (public.is_portaria());
create policy tm_reservations_delete on public.reservations for delete to authenticated using (public.is_portaria());

create policy tm_moves_read on public.moves for select to authenticated using (public.is_portaria() or apartment = public.current_user_apartment());
create policy tm_moves_insert on public.moves for insert to authenticated with check (apartment = public.current_user_apartment() and requested_by = auth.uid());
create policy tm_moves_update on public.moves for update to authenticated using (public.is_portaria()) with check (public.is_portaria());
create policy tm_moves_delete on public.moves for delete to authenticated using (public.is_portaria());

create policy tm_service_requests_read on public.service_requests for select to authenticated using (public.is_portaria() or apartment = public.current_user_apartment());
create policy tm_service_requests_insert on public.service_requests for insert to authenticated with check (apartment = public.current_user_apartment() and created_by = auth.uid());
create policy tm_service_requests_update on public.service_requests for update to authenticated using (public.is_portaria()) with check (public.is_portaria());

grant usage on schema public to authenticated;
grant select on public.apartments to authenticated;
grant select, update on public.profiles to authenticated;
grant select, insert, update, delete on public.residents, public.visitors, public.family_members,
  public.workers, public.packages, public.package_events, public.accesses,
  public.reservations, public.moves, public.service_requests, public.apartment_invites to authenticated;
grant execute on function public.current_user_role() to authenticated;
grant execute on function public.current_user_apartment() to authenticated;
grant execute on function public.is_portaria() to authenticated;

commit;
