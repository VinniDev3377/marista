-- Compatibilidade com o esquema já criado pelo Talk Marista.
-- Não recria tabelas nem remove registros existentes.
begin;

-- A foto da encomenda é opcional; a coluna é adicionada de forma incremental.
alter table public.packages add column if not exists photo_path text;

-- Bucket privado para fotos de encomendas.
insert into storage.buckets (id, name, public)
values ('package-photos', 'package-photos', false)
on conflict (id) do update set public = false;

drop policy if exists tm_package_photos_read on storage.objects;
create policy tm_package_photos_read on storage.objects
for select to authenticated
using (
  bucket_id = 'package-photos'
  and (public.is_portaria() or (storage.foldername(name))[1] = public.current_user_apartment())
);

drop policy if exists tm_package_photos_insert on storage.objects;
create policy tm_package_photos_insert on storage.objects
for insert to authenticated
with check (bucket_id = 'package-photos' and public.is_portaria());

drop policy if exists tm_package_photos_update on storage.objects;
create policy tm_package_photos_update on storage.objects
for update to authenticated
using (bucket_id = 'package-photos' and public.is_portaria())
with check (bucket_id = 'package-photos' and public.is_portaria());

-- Registra automaticamente o histórico de recebimento e retirada de encomendas.
create or replace function public.talk_marista_package_event()
returns trigger
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
begin
  if tg_op = 'INSERT' then
    insert into public.package_events (package_id, apartment, event_type, description, actor_id)
    values (new.id, new.apartment, 'received', 'Encomenda registrada na portaria', coalesce(new.received_by, auth.uid()));
  elsif new.status is distinct from old.status then
    insert into public.package_events (package_id, apartment, event_type, description, actor_id)
    values (new.id, new.apartment, lower(new.status), 'Status alterado para ' || new.status, coalesce(new.withdrawn_by, auth.uid()));
  end if;
  return new;
end;
$$;
revoke all on function public.talk_marista_package_event() from public, anon, authenticated;
drop trigger if exists talk_marista_package_event_trigger on public.packages;
create trigger talk_marista_package_event_trigger
after insert or update of status on public.packages
for each row execute function public.talk_marista_package_event();

commit;
